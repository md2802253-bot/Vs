'use strict';
/* REX TEAM GAMING SOUNDBOARD — vanilla JS, Web Audio API, IndexedDB, LocalStorage */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const ICONS = ['🔊', '🔥', '💀', '🎯', '💥', '😂', '🎮', '🚨', '👑', '⚡', '🥁', '🎵', '🤖', '👻', '🏆', '❤️'];

/* ---------- Settings (LocalStorage) ---------- */
const DEFAULTS = { theme: 'dark', master: 0.8, maxPoly: 8, eq: { bass: 0, mid: 0, treble: 0 }, fx: 'none', gaming: false, float: false,
  cats: ['General', 'Funny', 'Gaming', 'Alerts'], recent: [], plays: 0 };
let cfg = DEFAULTS;
try { cfg = { ...DEFAULTS, ...JSON.parse(localStorage.getItem('rex_cfg') || '{}') }; } catch { /* corrupt settings -> defaults */ }
const saveCfg = () => localStorage.setItem('rex_cfg', JSON.stringify(cfg));

/* ---------- IndexedDB (persistent audio blobs) ---------- */
let db;
const openDB = () => new Promise((res, rej) => {
  const r = indexedDB.open('rexDB', 1);
  r.onupgradeneeded = () => r.result.createObjectStore('sounds', { keyPath: 'id' });
  r.onsuccess = () => { db = r.result; res(); };
  r.onerror = () => rej(r.error);
});
const store = m => db.transaction('sounds', m).objectStore('sounds');
const rq = r => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const dbAll = () => rq(store('readonly').getAll());
const dbPut = s => rq(store('readwrite').put(s));
const dbDel = id => rq(store('readwrite').delete(id));
const dbClear = () => rq(store('readwrite').clear());

/* ---------- Web Audio graph ----------
   sound gain -> master -> bass -> mid -> treble -> fxBus -> compressor (anti-clipping) -> speakers */
let ctx, N = {};
const buffers = new Map();   // decoded AudioBuffers cache
const active = new Map();    // id -> {src, g, start, offset, paused}
function initAudio() {
  if (ctx) return;
  ctx = new (window.AudioContext || window.webkitAudioContext)();
  const f = (type, freq, Q) => { const n = ctx.createBiquadFilter(); n.type = type; n.frequency.value = freq; if (Q) n.Q.value = Q; return n; };
  N.master = ctx.createGain();
  N.bass = f('lowshelf', 200); N.mid = f('peaking', 1000, 1); N.treble = f('highshelf', 3500);
  N.fx = ctx.createGain();
  N.comp = ctx.createDynamicsCompressor();
  N.comp.threshold.value = -12; N.comp.knee.value = 24; N.comp.ratio.value = 12; N.comp.attack.value = 0.003; N.comp.release.value = 0.25;
  N.master.connect(N.bass); N.bass.connect(N.mid); N.mid.connect(N.treble); N.treble.connect(N.fx);
  N.comp.connect(ctx.destination);
  applyAudioCfg();
}
function applyAudioCfg() {
  if (!ctx) return;
  N.master.gain.value = cfg.master;
  N.bass.gain.value = cfg.eq.bass; N.mid.gain.value = cfg.eq.mid; N.treble.gain.value = cfg.eq.treble;
  // rebuild effect routing
  N.fx.disconnect(); (N.extra || []).forEach(n => { try { n.disconnect(); } catch { } }); N.extra = [];
  const mk = (t, v) => { const g = ctx.createGain(); g.gain.value = v; return g; };
  if (cfg.fx === 'echo') {
    const d = ctx.createDelay(1); d.delayTime.value = 0.28; const fb = mk(0, 0.35), w = mk(0, 0.5);
    N.fx.connect(N.comp); N.fx.connect(d); d.connect(fb); fb.connect(d); d.connect(w); w.connect(N.comp); N.extra = [d, fb, w];
  } else if (cfg.fx === 'reverb') {
    const len = ctx.sampleRate * 1.8, imp = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) { const d = imp.getChannelData(c); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3); }
    const cv = ctx.createConvolver(); cv.buffer = imp; const w = mk(0, 0.45);
    N.fx.connect(N.comp); N.fx.connect(cv); cv.connect(w); w.connect(N.comp); N.extra = [cv, w];
  } else if (cfg.fx === 'radio' || cfg.fx === 'deep') {
    const b = ctx.createBiquadFilter(); b.type = cfg.fx === 'radio' ? 'bandpass' : 'lowpass';
    b.frequency.value = cfg.fx === 'radio' ? 1800 : 900; b.Q.value = 0.8;
    N.fx.connect(b); b.connect(N.comp); N.extra = [b];
  } else N.fx.connect(N.comp);
}
// Autoplay policy: the context may only start from a user gesture, so every play() calls ensure().
async function ensure() {
  initAudio();
  if (ctx.state !== 'running') await ctx.resume();
  if (ctx.state !== 'running') throw new Error('Audio is blocked by the browser. Tap the screen and try again.');
}
async function getBuf(s) {
  if (buffers.has(s.id)) return buffers.get(s.id);
  const b = await ctx.decodeAudioData(await s.blob.arrayBuffer());
  buffers.set(s.id, b); return b;
}

/* ---------- Playback controls ---------- */
async function play(s, from = 0) {
  try {
    await ensure();
    const buf = await getBuf(s);
    stop(s.id, true);
    // enforce simultaneous-sound limit by dropping the oldest playing sound
    let running = [...active.entries()].filter(([, a]) => !a.paused);
    while (running.length >= cfg.maxPoly) { stop(running.shift()[0], true); }
    const src = ctx.createBufferSource(); src.buffer = buf; src.loop = !!s.loop;
    const g = ctx.createGain(); g.gain.value = s.vol;
    src.connect(g); g.connect(N.master);
    const a = { src, g, start: ctx.currentTime - from, offset: 0, paused: false };
    src.onended = () => { if (active.get(s.id) === a && !a.paused) { active.delete(s.id); renderAll(); } };
    src.start(0, from % buf.duration);
    active.set(s.id, a);
    if (!from) { cfg.recent = [s.id, ...cfg.recent.filter(i => i !== s.id)].slice(0, 8); cfg.plays++; saveCfg(); }
    renderAll();
  } catch (e) { toast('Playback error: ' + (e.message || e)); }
}
function pauseToggle(s) {
  const a = active.get(s.id);
  if (!a) return play(s);
  if (a.paused) return play(s, a.offset);
  a.offset = (ctx.currentTime - a.start) % a.src.buffer.duration; a.paused = true;
  a.src.onended = null; try { a.src.stop(); } catch { } renderAll();
}
function stop(id, silent) {
  const a = active.get(id); if (!a) return;
  a.src.onended = null; try { a.src.stop(); } catch { } a.g.disconnect(); active.delete(id);
  if (!silent) renderAll();
}
const stopAll = () => { [...active.keys()].forEach(id => stop(id, true)); renderAll(); };

/* ---------- Data & rendering ---------- */
let sounds = [], filterCat = 'All', query = '';
const byId = id => sounds.find(s => s.id === id);
async function load() { sounds = (await dbAll()).sort((a, b) => a.created - b.created); renderAll(); }
const bars = p => (p || []).map(v => `<i style="height:${Math.max(8, v * 100)}%"></i>`).join('');
function card(s) {
  const a = active.get(s.id), st = a ? (a.paused ? 'paused' : 'playing') : '';
  return `<div class="card ${st}" data-id="${s.id}" style="--c:${s.color}">
  <button class="pad" data-act="play"><span class="ic">${esc(s.icon)}</span><span class="nm">${esc(s.name)}</span><span class="wf">${bars(s.peaks)}</span><small>${fmt(s.dur)} · ${esc(s.cat)}</small></button>
  <div class="ctl"><button data-act="pause" title="Pause / Resume">${st === 'playing' ? '⏸' : '▶'}</button><button data-act="stop" title="Stop">⏹</button>
  <button data-act="loop" class="${s.loop ? 'on' : ''}" title="Loop">🔁</button><button data-act="fav" class="${s.fav ? 'on' : ''}" title="Favorite">${s.fav ? '★' : '☆'}</button><button data-act="edit" title="Edit">✎</button></div>
  <input type="range" data-act="vol" min="0" max="1" step="0.01" value="${s.vol}" aria-label="Volume"></div>`;
}
const list = (arr, msg) => arr.length ? arr.map(card).join('') : `<div class="empty">${msg}</div>`;
function renderAll() {
  if (dragging) return;
  const q = query.toLowerCase();
  const shown = sounds.filter(s => (filterCat === 'All' || s.cat === filterCat) && s.name.toLowerCase().includes(q));
  $('#grid').innerHTML = list(shown, sounds.length ? 'No sounds match.' : 'No sounds yet. Tap “＋ Add” to upload your first one.');
  $('#favGrid').innerHTML = list(sounds.filter(s => s.fav), 'No favorites yet. Tap ☆ on a sound.');
  $('#recent').innerHTML = list(cfg.recent.map(byId).filter(Boolean), 'Nothing played yet.');
  $('#chips').innerHTML = ['All', ...cfg.cats].map(c => `<button class="chip ${c === filterCat ? 'on' : ''}" data-cat="${esc(c)}">${esc(c)}</button>`).join('');
  $('#catList').innerHTML = cfg.cats.map(c => `<div class="catRow"><b>${esc(c)}</b><span>${sounds.filter(s => s.cat === c).length} sounds</span>
    <button class="btn ghost" data-open="${esc(c)}">Open</button>${c === 'General' ? '' : `<button class="btn danger" data-delcat="${esc(c)}">✕</button>`}</div>`).join('');
  $('#stSounds').textContent = sounds.length; $('#stCats').textContent = cfg.cats.length;
  $('#stFavs').textContent = sounds.filter(s => s.fav).length; $('#stPlays').textContent = cfg.plays;
  $('#miniFavs').innerHTML = sounds.filter(s => s.fav).map(s => `<button data-id="${s.id}" style="--c:${s.color}">${esc(s.icon)} ${esc(s.name)}</button>`).join('') || '<small>No favorites</small>';
}

/* ---------- Events: cards (delegated) ---------- */
let dragging = false;
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-act]'); const c = e.target.closest('.card');
  if (b && c && b.dataset.act !== 'vol') {
    const s = byId(c.dataset.id); if (!s) return;
    const act = b.dataset.act;
    if (act === 'play') play(s);
    else if (act === 'pause') pauseToggle(s);
    else if (act === 'stop') stop(s.id);
    else if (act === 'loop') { s.loop = !s.loop; const a = active.get(s.id); if (a) a.src.loop = s.loop; await dbPut(s); renderAll(); }
    else if (act === 'fav') { s.fav = !s.fav; await dbPut(s); renderAll(); }
    else if (act === 'edit') openDlg(s);
  }
  const chip = e.target.closest('[data-cat]'); if (chip) { filterCat = chip.dataset.cat; renderAll(); }
  const op = e.target.closest('[data-open]'); if (op) { filterCat = op.dataset.open; showView('board'); renderAll(); }
  const dc = e.target.closest('[data-delcat]'); if (dc) deleteCat(dc.dataset.delcat);
  const mf = e.target.closest('#miniFavs button[data-id]'); if (mf) play(byId(mf.dataset.id));
});
// per-sound volume: update live without re-rendering; persist on release
document.addEventListener('input', e => {
  if (e.target.dataset.act !== 'vol') return;
  dragging = true; const s = byId(e.target.closest('.card').dataset.id); s.vol = +e.target.value;
  const a = active.get(s.id); if (a) a.g.gain.value = s.vol;
});
document.addEventListener('change', async e => {
  if (e.target.dataset.act !== 'vol') return;
  dragging = false; await dbPut(byId(e.target.closest('.card').dataset.id)); renderAll();
});

/* ---------- Navigation ---------- */
function showView(v) {
  $$('.view').forEach(x => x.classList.toggle('active', x.id === 'v-' + v));
  $$('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.view === v));
  scrollTo(0, 0);
}
$$('.tabs button').forEach(b => b.onclick = () => showView(b.dataset.view));
$('#stopAll').onclick = stopAll; $('#miniStop').onclick = stopAll;
$('#search').oninput = e => { query = e.target.value; renderAll(); };

/* ---------- Categories ---------- */
$('#addCat').onclick = () => {
  const n = $('#newCat').value.trim();
  if (!n) return toast('Enter a category name.');
  if (cfg.cats.some(c => c.toLowerCase() === n.toLowerCase())) return toast('Category already exists.');
  cfg.cats.push(n); saveCfg(); $('#newCat').value = ''; renderAll();
};
async function deleteCat(c) {
  if (!confirm(`Delete category “${c}”? Its sounds move to General.`)) return;
  cfg.cats = cfg.cats.filter(x => x !== c); if (filterCat === c) filterCat = 'All'; saveCfg();
  for (const s of sounds.filter(s => s.cat === c)) { s.cat = 'General'; await dbPut(s); }
  renderAll();
}

/* ---------- Add / Edit dialog ---------- */
let editing = null, pending = null, prevUrl = null;
$('#fIcon').innerHTML = ICONS.map(i => `<option>${i}</option>`).join('');
function drawWave(peaks) {
  const cv = $('#prevWave'), g = cv.getContext('2d'); g.clearRect(0, 0, cv.width, cv.height); g.fillStyle = '#ff1744';
  (peaks || []).forEach((v, i, a) => { const w = cv.width / a.length, h = Math.max(2, v * cv.height); g.fillRect(i * w + 1, (cv.height - h) / 2, w - 2, h); });
}
function openDlg(s) {
  editing = s || null; pending = null;
  $('#dlgTitle').textContent = s ? 'Edit Sound' : 'Add Sound';
  $('#fCat').innerHTML = cfg.cats.map(c => `<option>${esc(c)}</option>`).join('');
  $('#fFile').value = ''; $('#fName').value = s ? s.name : ''; $('#fCat').value = s ? s.cat : (filterCat !== 'All' ? filterCat : 'General');
  $('#fIcon').value = s ? s.icon : ICONS[0]; $('#fColor').value = s ? s.color : '#ff1744';
  $('#fVol').value = s ? s.vol : 1; $('#fLoop').checked = s ? s.loop : false; $('#fDel').hidden = !s;
  if (prevUrl) URL.revokeObjectURL(prevUrl);
  prevUrl = s ? URL.createObjectURL(s.blob) : null; $('#prevAudio').src = prevUrl || '';
  drawWave(s && s.peaks); $('#dlg').showModal();
}
$('#addBtn').onclick = () => openDlg(null);
$('#fCancel').onclick = () => { $('#prevAudio').pause(); $('#dlg').close(); };
$('#fFile').onchange = async e => {
  const f = e.target.files[0]; if (!f) return;
  if (!/\.(mp3|wav|ogg)$/i.test(f.name) && !/^audio\/(mpeg|mp3|wav|x-wav|ogg)/.test(f.type)) { e.target.value = ''; return toast('Only MP3, WAV and OGG files are supported.'); }
  if (f.size > 25 * 1024 * 1024) { e.target.value = ''; return toast('File too large (max 25 MB).'); }
  try {
    initAudio();
    const buf = await ctx.decodeAudioData(await f.arrayBuffer());       // validates the file & gives duration
    const data = buf.getChannelData(0), n = 48, step = Math.floor(data.length / n), peaks = [];
    for (let i = 0; i < n; i++) { let m = 0; for (let j = i * step; j < (i + 1) * step; j += 50) m = Math.max(m, Math.abs(data[j] || 0)); peaks.push(+m.toFixed(2)); }
    pending = { blob: f, dur: buf.duration, peaks };
    if (prevUrl) URL.revokeObjectURL(prevUrl);
    prevUrl = URL.createObjectURL(f); $('#prevAudio').src = prevUrl; drawWave(peaks);   // preview before saving
    if (!$('#fName').value) $('#fName').value = f.name.replace(/\.[^.]+$/, '').slice(0, 30);
  } catch { pending = null; e.target.value = ''; toast('Could not decode this audio file. It may be corrupted.'); }
};
$('#fSave').onclick = async () => {
  const name = $('#fName').value.trim();
  if (!name) return toast('Please enter a name.');
  if (!editing && !pending) return toast('Please choose an audio file.');
  const s = editing || { id: crypto.randomUUID(), created: Date.now(), fav: false };
  Object.assign(s, { name, cat: $('#fCat').value, icon: $('#fIcon').value, color: $('#fColor').value, vol: +$('#fVol').value, loop: $('#fLoop').checked });
  if (pending) { Object.assign(s, pending); buffers.delete(s.id); stop(s.id, true); }
  try {
    await dbPut(s); $('#prevAudio').pause(); $('#dlg').close();
    if (!editing) sounds.push(s);
    navigator.storage?.persist?.(); renderAll(); toast('Saved ✔');
  } catch { toast('Storage error: could not save (device storage full?).'); }
};
$('#fDel').onclick = async () => {
  if (!confirm('Delete this sound permanently?')) return;
  stop(editing.id, true); buffers.delete(editing.id); await dbDel(editing.id);
  sounds = sounds.filter(s => s.id !== editing.id); cfg.recent = cfg.recent.filter(i => i !== editing.id); saveCfg();
  $('#prevAudio').pause(); $('#dlg').close(); renderAll();
};

/* ---------- Settings ---------- */
function syncSettings() {
  document.documentElement.dataset.theme = cfg.theme; document.body.classList.toggle('gaming', cfg.gaming);
  $('#master').value = cfg.master; $('#masterOut').textContent = Math.round(cfg.master * 100) + '%';
  $('#maxPoly').value = cfg.maxPoly; $('#eqBass').value = cfg.eq.bass; $('#eqMid').value = cfg.eq.mid; $('#eqTreble').value = cfg.eq.treble;
  $('#fx').value = cfg.fx; $('#theme').value = cfg.theme; $('#gaming').checked = cfg.gaming; $('#floatOn').checked = cfg.float;
  $('#mini').hidden = !cfg.float; $('meta[name=theme-color]').content = cfg.theme === 'dark' ? '#0a0a0a' : '#f4f4f6';
}
const bind = (id, fn) => $(id).addEventListener('input', e => { fn(e.target); saveCfg(); applyAudioCfg(); syncSettings(); });
bind('#master', t => cfg.master = +t.value);
bind('#maxPoly', t => cfg.maxPoly = Math.min(32, Math.max(1, parseInt(t.value) || 1)));
bind('#eqBass', t => cfg.eq.bass = +t.value); bind('#eqMid', t => cfg.eq.mid = +t.value); bind('#eqTreble', t => cfg.eq.treble = +t.value);
bind('#fx', t => cfg.fx = t.value); bind('#theme', t => cfg.theme = t.value); bind('#floatOn', t => cfg.float = t.checked);
$('#gaming').onchange = async e => {
  cfg.gaming = e.target.checked; saveCfg(); syncSettings();
  try { // keep the screen awake in gaming mode where supported
    if (cfg.gaming && 'wakeLock' in navigator) wake = await navigator.wakeLock.request('screen'); else if (wake) { wake.release(); wake = null; }
  } catch { toast('Wake lock not available; gaming mode applied without it.'); }
};
let wake = null;
$('#eqReset').onclick = () => { cfg.eq = { bass: 0, mid: 0, treble: 0 }; cfg.fx = 'none'; saveCfg(); applyAudioCfg(); syncSettings(); };

/* ---------- Microphone permission & test ---------- */
let micStream = null, micRaf = 0, micCtx = null;
$('#micBtn').onclick = async () => {
  if (micStream) return stopMic('Mic test stopped.');
  if (!navigator.mediaDevices?.getUserMedia) return $('#micMsg').textContent = 'Microphone is not supported here (HTTPS is required).';
  try {
    micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    micCtx = new (window.AudioContext || window.webkitAudioContext)();
    const an = micCtx.createAnalyser(); an.fftSize = 512; micCtx.createMediaStreamSource(micStream).connect(an);  // not routed to speakers: no feedback
    const d = new Uint8Array(an.fftSize); $('#micBtn').textContent = '⏹ Stop Mic Test'; $('#micMsg').textContent = 'Mic working — speak now.';
    (function loop() { an.getByteTimeDomainData(d); let m = 0; d.forEach(v => m = Math.max(m, Math.abs(v - 128))); $('#micBar').style.width = Math.min(100, m / 128 * 160) + '%'; micRaf = requestAnimationFrame(loop); })();
  } catch (e) {
    const m = { NotAllowedError: 'Permission denied. Allow the microphone in Chrome site settings.', NotFoundError: 'No microphone found.', NotReadableError: 'Microphone is used by another app.' };
    $('#micMsg').textContent = m[e.name] || 'Microphone error: ' + e.message;
  }
};
function stopMic(msg) {
  cancelAnimationFrame(micRaf); micStream?.getTracks().forEach(t => t.stop()); micCtx?.close(); micStream = null;
  $('#micBar').style.width = 0; $('#micBtn').textContent = '🎤 Start Mic Test'; $('#micMsg').textContent = msg;
}

/* ---------- Backup: export / import / clear ---------- */
const toDataURL = b => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(b); });
$('#exportBtn').onclick = async () => {
  try {
    const out = { app: 'REX', v: 1, cfg, sounds: await Promise.all(sounds.map(async s => ({ ...s, blob: await toDataURL(s.blob), mime: s.blob.type }))) };
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(out)], { type: 'application/json' }));
    a.download = 'rex-soundboard-backup.json'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  } catch { toast('Export failed.'); }
};
$('#importFile').onchange = async e => {
  const f = e.target.files[0]; if (!f) return;
  try {
    const d = JSON.parse(await f.text()); if (d.app !== 'REX') throw 0;
    for (const s of d.sounds) { s.blob = await (await fetch(s.blob)).blob(); delete s.mime; await dbPut(s); }
    cfg = { ...cfg, cats: [...new Set([...cfg.cats, ...(d.cfg?.cats || [])])] }; saveCfg(); await load(); toast(`Imported ${d.sounds.length} sounds ✔`);
  } catch { toast('Invalid backup file.'); }
  e.target.value = '';
};
$('#clearSounds').onclick = async () => { if (!confirm('Delete ALL sounds?')) return; stopAll(); await dbClear(); buffers.clear(); sounds = []; cfg.recent = []; saveCfg(); renderAll(); toast('All sounds deleted.'); };
$('#resetAll').onclick = async () => {
  if (!confirm('Reset everything (sounds and settings)?')) return;
  await dbClear(); localStorage.removeItem('rex_cfg'); location.reload();
};

/* ---------- Misc: toast, PWA install, boot ---------- */
let tt; function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('show'), 3200); }
let deferred; addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; $('#installBtn').hidden = false; });
$('#installBtn').onclick = async () => { if (!deferred) return; deferred.prompt(); await deferred.userChoice; deferred = null; $('#installBtn').hidden = true; };
document.addEventListener('visibilitychange', async () => { if (cfg.gaming && wake === null && document.visibilityState === 'visible' && 'wakeLock' in navigator) try { wake = await navigator.wakeLock.request('screen'); } catch { } });
(async function boot() {
  syncSettings();
  try { await openDB(); await load(); } catch { toast('Storage unavailable (private mode?). Sounds cannot be saved.'); }
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('service-worker.js').catch(() => { });
})();
